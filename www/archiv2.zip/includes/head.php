<?php require $_SERVER['DOCUMENT_ROOT'].'/includes/version.php'; ?>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/styles.css?v=<?= htmlspecialchars($ASSET_VERSION) ?>">
<script src="/assets/js/main.js?v=<?= htmlspecialchars($ASSET_VERSION) ?>" defer></script>






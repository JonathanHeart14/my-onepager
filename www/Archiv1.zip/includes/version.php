<?php
// Ein Wert für alle Assets – änderst du nur, wenn CSS/JS geändert wurde
$ASSET_VERSION = '2025-11-06v3';
